//
//  FaceEnrollmentFramework.h
//  FaceEnrollmentFramework
//
//  Created by Emmanuel Mtera on 5/24/23.
//

#import <Foundation/Foundation.h>

//! Project version number for FaceEnrollmentFramework.
FOUNDATION_EXPORT double FaceEnrollmentFrameworkVersionNumber;

//! Project version string for FaceEnrollmentFramework.
FOUNDATION_EXPORT const unsigned char FaceEnrollmentFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaceEnrollmentFramework/PublicHeader.h>


