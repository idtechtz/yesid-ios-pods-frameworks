//
//  FaceAuthFramework.h
//  FaceAuthFramework
//
//  Created by Emmanuel Mtera on 5/24/23.
//

#import <Foundation/Foundation.h>

//! Project version number for FaceAuthFramework.
FOUNDATION_EXPORT double FaceAuthFrameworkVersionNumber;

//! Project version string for FaceAuthFramework.
FOUNDATION_EXPORT const unsigned char FaceAuthFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaceAuthFramework/PublicHeader.h>


