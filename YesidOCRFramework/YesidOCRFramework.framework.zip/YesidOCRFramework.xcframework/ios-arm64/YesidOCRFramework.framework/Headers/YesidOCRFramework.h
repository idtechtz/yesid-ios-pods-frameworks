//
//  YesidOCRFramework.h
//  YesidOCRFramework
//
//  Created by Emmanuel Mtera on 5/24/23.
//

#import <Foundation/Foundation.h>

//! Project version number for YesidOCRFramework.
FOUNDATION_EXPORT double YesidOCRFrameworkVersionNumber;

//! Project version string for YesidOCRFramework.
FOUNDATION_EXPORT const unsigned char YesidOCRFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YesidOCRFramework/PublicHeader.h>


